package com.example.myapplication;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("api/")
    Call<Results> getData(@Query("joke") String params);
    // Inne metody dla różnych żądań HTTP


}

