package com.example.myapplication;

public class Results {
    private String id;
    private String joke;
    private int status;
}
