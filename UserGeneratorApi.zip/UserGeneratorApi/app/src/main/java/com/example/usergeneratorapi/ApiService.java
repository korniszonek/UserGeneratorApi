package com.example.usergeneratorapi;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("api/")
    Call<Results> getData(@Query("inc") String params);
    // Inne metody dla różnych żądań HTTP


}

 /*   package com.example.usergeneratorapi;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
public interface ApiService {
    @GET("?inc/{gender},{name},{nat}")
    Call<?inc> getGender(@Path("?inc") String nameId);
    // Inne metody dla różnych żądań HTTP
}*/