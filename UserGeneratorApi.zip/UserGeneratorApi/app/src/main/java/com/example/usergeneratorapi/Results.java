package com.example.usergeneratorapi;

public class Results {
    public int gender;
    public Name name;
    public String nat;


}
