package com.example.myapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    public final int REQUEST_INTERNET_PERMISSION = 1;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        apiService =ApiClient.getRetrofitInstance().create(ApiService.class);
        Button but = (Button) findViewById(R.id.sendRequest);
        but.setOnClickListener(e->{
            Call<Results> call = apiService.getData();
            call.enqueue(new Callback<Results>() {
                @Override
                public void onResponse(Call<Results> call, Response<Results> response){
                    if (response.isSuccessful()) {
                        Results results = response.body();
                        Toast.makeText(getApplicationContext(), results.attachments.get(0).text, Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(getApplicationContext(), "Bład requesta", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<Results> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), "Błąd API nie działa!",
                            Toast.LENGTH_LONG).show();
                }

            });
        });
    }
    private void action() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.INTERNET}, REQUEST_INTERNET_PERMISSION);
            return;
        }
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_INTERNET_PERMISSION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Przyznano uprawnienia", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Nie przyznano uprawnień", Toast.LENGTH_LONG).show();
        }
    }
}