package com.example.myapplication;

import java.util.ArrayList;

public class Results {
    public ArrayList<attachment> attachments;
    public String response_type;
    public String username;




}
