package com.example.myapplication;

public class attachment{
    public String fallback;
    public String footer;
    public String text;
    
}
